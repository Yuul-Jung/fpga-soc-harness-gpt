# 복합 주변장치 제어 — PIR 움직임 + HC-SR04 거리 → LED PWM

## 구현 수준
독립 캡스톤 설계안. RTL·테스트벤치·C·AXI·Vivado·실물 보드는 미구현/미검증.

## 기능 요구사항
- 입력 1: PIR 움직임 (전기적 특성·출력 신호·샘플 유효 조건을 확인한 뒤 연결)
- 입력 2: HC-SR04 거리 (서로 다른 샘플 주기와 비동기 이벤트를 구분)
- 제어 정책: 이중 조건 일치 시 동작. Reset과 타임아웃/센서 오류의 안전 상태 정의
- 출력: LED PWM (전원/구동 회로 별도 검토)
- 진단: UART 이벤트 (유효값, 오류, 마지막 이벤트와 상태 구분)

## 회로 구조 (모듈명은 신규 제안, 실제 RTL 포트 아님)
PIR 움직임 → sensor_a.sample → capstone_controller.sample_a
HC-SR04 거리 → sensor_b.sample → capstone_controller.sample_b
capstone_controller.command → LED PWM
capstone_controller.status → UART 이벤트

## 구현 절차
1. 모듈별 실제 데이터시트·핀·3.3V 호환성 및 외부 부하 전원 검토
2. 두 입력의 샘플 시점, 이벤트 펄스, 클럭 도메인·Reset 정의
3. Controller FSM과 입력 유효성·타임아웃·우선순위 규칙 확정
4. 독립 RTL 및 자기검증 테스트벤치 작성 후 시뮬레이션
5. 필요한 경우 AXI GPIO/사용자 AXI IP로 MicroBlaze V 연결
6. Vivado 합성·타이밍·XDC·실물 보드 검증을 각각 별도 기록

## 검증 시나리오
- Reset 후 출력 안전 상태
- 입력 1만 발생 / 입력 2만 발생 / 두 입력 동시 발생
- 입력 변화 순서 반대 / 바운스 / 입력 무효 및 타임아웃
- 출력 구동 중 재입력 / 긴급 중지 / 복귀 동작
- 표시 및 레지스터 값과 실제 이벤트의 일치

## 안전 및 출처
Basys3 GPIO 3.3V, XADC 단극성 입력 0~1V. 5V 신호·모터·릴레이·서보 부하 직결 금지. 실제 보드별 전압 변환 및 구동회로 검증 필요.
독립적으로 작성한 설계안. 외부 코드·이미지 복제 없음.
